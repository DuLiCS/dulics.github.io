---


layout: post
title: Haskell 99 questions 31 to 40
subtitle: 31-40
tags: [Haskell, Code]

---

<head>
    <script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>
    <script type="text/x-mathjax-config">
        MathJax.Hub.Config({
            tex2jax: {
            skipTags: ['script', 'noscript', 'style', 'textarea', 'pre'],
            inlineMath: [['$','$']]
            }
        });
    </script>
</head>



## Problem 31
(**) Determine whether a given integer number is prime.

Example:

、、、
* (is-prime 7)
T
、、、

Example in Haskell:

、、
λ> isPrime 7
True

、、、

```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
```haskell

```
