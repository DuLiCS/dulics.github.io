---
layout: post
title: My very first post
tags: [essay]
---

It's another Xmas day. I still remember the same day last year, in a blink, a whole year has passed, at the beginning of a new year and the end of the old year. People always have mixed emotions, including the hope to the next year, on the other hand, the regret of the time passed by.

I got the Kukuyo journal today, I took a picture below, the 2019-journal is red, and I deliberately choose the blue one as my new journal. I hope this could lead to a brave new life.

Merry Xmas!

![](/img/kuo.jpg)
