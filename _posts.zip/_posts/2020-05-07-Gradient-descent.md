---

layout: post
title: Gradient Descent
subtitle: Wiki
tags: [Machine Learning, Wiki]

---


在学习的过程中,我觉得很有必要好好讲一下Gradient Descent这里的知识点.原因是实在用的太多了,不能不吃透.对于这部分知识似懂非懂一定是不行的,所以预计画一到两天时间把这部分知识吃透.

