---
layout: post
title: Intriguing Question And Some Thinking 
subtitle: Just some little things in my life
tags: [essay]
---

When my iPhone screen lit up, I saw a Wechat app notification popup message. I touched the icon and entered the app, and an intriguing question jumped into my eyes. (I tagged the image below).

![](/img/question.jpg)

It seems to be an easy question for the first glance. So I directly wrote the following solution to the problem. Just as you see, I employed a fraction to replace the division calculation and remove the common elements. I used another solution to verify my result, because of the unspecified feature, that is to say, every B that is above two and its corresponding number A can precisely prove my solution and..., I got an incorrect answer.

![](/img/solution.jpg)

I don't want to paste the correct answer to this question here, and I prefer to leave this "dilemma" for you. It is a math question for grade four, and it's obviously not a complicated problem. But the Intriguing thing is I did it wrong, and I insisted on my point until other people told me the right answer. This process even lasts for an hour. I write this just want to remind myself that I should neither think too hard nor too simple when I face a new problem, and people are more stubborn than we expected.
